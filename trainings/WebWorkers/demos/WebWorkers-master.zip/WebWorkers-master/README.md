# WebWorkers
Demos with web workers 

1. Basic setup
2. Heavy calculations
3. Sub worker
4. API implementation
5. Multiple threads
6. Transferable objects
