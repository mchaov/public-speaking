onmessage = function(e) {
	console.log('w1');
    postMessage({call1: ''});
};

//close();