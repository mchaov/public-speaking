importScripts('network-check.js');

onmessage = function(e) {
};